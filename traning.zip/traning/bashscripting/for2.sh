#!/bin/bash
for var in $(ls)
do
echo $var
done

