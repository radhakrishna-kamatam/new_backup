#!/bin/bash
for variable in file1 file2
do
cat $variable
echo "###############"
done

