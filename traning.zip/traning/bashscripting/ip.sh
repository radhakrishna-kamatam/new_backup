#!/bin/bash
for i in `cat host.sh`
do
echo $i
done

