#!/bin/bash
for variable in {1..10}
do
echo $variable
done
