#!/bin/bash
var2=football
echo $var1
echo $var2
