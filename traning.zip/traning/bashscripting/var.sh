#!/bin/bash
intA=123
floatB=200.20
stringA="first string"
DIR_PARH="bashscripting"


echo
echo "value of integer A is $intA"
echo "value of float B is $floatB "
echo "value of string is $stringA "
echo "dir tpath is $DIR_PATH"
ls DIR_PATH
